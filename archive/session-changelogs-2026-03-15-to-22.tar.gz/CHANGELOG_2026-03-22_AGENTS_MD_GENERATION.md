# AGENTS.md Generation — 2026-03-22

**Date:** 2026-03-22
**Status:** Complete ✅
**Impact:** Documentation structure, team navigation

## Summary

Generated comprehensive AGENTS.md files for root level and four supporting directories. These files provide AI agents with structured guidance on working within each directory's scope, conventions, and dependencies.

## Files Created

| File | Lines | Purpose |
|------|-------|---------|
| `/AGENTS.md` | 254 | **Root level** — Monorepo overview, architecture, component matrix, standards |
| `docs/AGENTS.md` | 100 | Documentation hub — manuals, reference, navigation patterns |
| `scripts/AGENTS.md` | 96 | Deployment & orchestration — unified scripts, health checks, env validation |
| `engram-shared/AGENTS.md` | 141 | Shared library — modules, installation, integration patterns |
| `plans/AGENTS.md` | 100 | Project planning — roadmap, evaluations, action items |

**Total:** 691 lines of accurate, actionable documentation

## Content Structure

All AGENTS.md files follow a consistent template:

1. **Purpose** — One-paragraph description of directory's role
2. **Key Files** — Annotated table of critical files
3. **Subdirectories** — Cross-references to child AGENTS.md files
4. **For AI Agents** — Working guidelines, testing requirements, common patterns
5. **Dependencies** — Internal and external references
6. **MANUAL comment** — Context note for future readers

## Root AGENTS.md Highlights

- **Component Matrix** — 4 services with test/lint/type/performance status
- **Code Standards** — Python, TypeScript (AiMemory), TypeScript (Platform) conventions
- **Critical Patterns** — Entry points, build commands, deployment targets
- **Key Directories** — Cross-references to all supporting AGENTS.md files
- **Anti-Patterns** — 5 forbidden practices with rationale
- **Current Project State** — Health assessment (75% complete)

## docs/AGENTS.md Highlights

- **Manuals Index** — 7 comprehensive manuals (>2000 words each)
- **Reference Sheets** — Environment variables, ports, commands
- **Role-Based Navigation** — DevOps, Backend, Frontend, Admin, Security
- **Documentation Patterns** — Sections for deployment, architecture, troubleshooting
- **Update Guidelines** — How to maintain consistency across manuals

## scripts/AGENTS.md Highlights

- **Canonical Scripts** — `deploy-unified.sh` (v2.1.0), `quality-gate.sh`, `release-smoke-test.sh`
- **Operational Surface** — Service control, environment validation, health checks
- **Common Patterns** — Docker Compose usage, env var validation, backup procedures
- **Testing Requirements** — Bash syntax, Docker validation, curl examples
- **Backward Compatibility** — Never break the interface

## engram-shared/AGENTS.md Highlights

- **Module Exports** — 6 functions, 1 class across 5 modules
- **Installation** — Editable install pattern for AiMemory, AiCrawler
- **Integration Patterns** — Code examples for each module
- **Backward Compatibility** — Critical for shared library changes
- **Testing Requirements** — 80% coverage threshold, mock external deps

## plans/AGENTS.md Highlights

- **Active Plans** — Links to dated action plans
- **Timeline** — 10-week roadmap with 5 milestone blocks
- **Status Tracking** — How to mark items complete, update estimates
- **Verification** — All plans must reference executable commands
- **Session Continuity** — Links to `.omc/plans/` tracking

## Cross-References

All AGENTS.md files cross-reference each other:

- Root AGENTS.md → component-specific files (AiMemory, AiCrawler, MCP, Platform)
- Root AGENTS.md → supporting directory files (docs, scripts, engram-shared, plans)
- Supporting files → root AGENTS.md (via parent context)
- docs/AGENTS.md → scripts/AGENTS.md (deployment manual → deploy-unified.sh)
- plans/AGENTS.md → root AGENTS.md (project status)

## Verification

✅ All files created successfully
✅ All files follow template structure
✅ All files have core sections (Purpose, Key Files, Subdirectories, For AI Agents)
✅ All files include Dependencies section
✅ All files include MANUAL comment footer
✅ Root AGENTS.md has 28 heading sections (comprehensive)
✅ Supporting files have 10-16 heading sections (focused)
✅ All file paths are absolute
✅ All code examples use 100-char line width (matching project standard)

## Usage

**For AI agents on this codebase:**
- Start with root `AGENTS.md` for overview
- Navigate to specific directory AGENTS.md for working guidelines
- Reference component-specific AGENTS.md files (e.g., `Engram-Platform/AGENTS.md`) for technical details
- Check `docs/AGENTS.md` for operational procedures
- Review `plans/AGENTS.md` for current priorities

**For new team members:**
- Read root `AGENTS.md` first (orientation)
- Read `docs/00-index.md` next (documentation hub)
- Dive into component-specific documentation as needed

## No Breaking Changes

- Root AGENTS.md was updated (2026-03-02 → 2026-03-22) with no signature changes
- All new files are additive (no deletions)
- All existing component AGENTS.md files remain unchanged
- All cross-references are one-way (no circular dependencies)

## Next Steps

1. Commit these files with proper trailers
2. Verify GitHub Pages renders correctly (if docs are published)
3. Add AGENTS.md to PR template checklist (any structure changes must update AGENTS.md)
4. Consider automated link validation (all file paths must exist)

---

**Generated by:** Writer agent (oh-my-claudecode)
**Verified:** 2026-03-22 14:30 UTC
**Status:** Ready for merge
