# Changelog — 2026-03-22 Cloudflare SSL + Devnode Deployment

## Summary

Completed Cloudflare DNS configuration and wildcard SSL certificate setup for `memory.velocitydigi.com`, plus verified devnode deployment.

## Cloudflare Configuration

### DNS Record (already present)
- `memory.velocitydigi.com` → `100.78.187.5` (A record, TTL 120, DNS-only)
- Matches `engram.velocitydigi.com` pattern (same target IP, same proxied=false)
- SSL mode: Full (Cloudflare ↔ origin encrypted)
- Universal SSL active for `*.velocitydigi.com` (Google Trust Services, expires 2026-04-30)

### Issue Found: Self-Signed Cert on Origin
- Nginx on devnode was using `nginx-selfsigned.crt` instead of Let's Encrypt
- Root cause: certs copied to wrong directory (`/opt/engram/certs` instead of `/opt/engram/Engram-Platform/certs`)

### Resolution: Let's Encrypt Wildcard Certificate
1. Obtained wildcard cert via certbot DNS-01 challenge (`*.velocitydigi.com`)
   - Provider: Let's Encrypt (via Cloudflare DNS-01)
   - Valid: 2026-03-22 → 2026-06-20 (90 days)
   - Cert path: `/etc/letsencrypt/live/velocitydigi.com/`
2. Copied to correct mount: `/opt/engram/Engram-Platform/certs/`
3. Updated `nginx.conf` SSL paths to use `velocitydigi.crt` / `velocitydigi.key`
4. Restarted `engram-nginx` container — cert now served correctly
5. Set up auto-renewal cron:
   ```
   certbot renew --dns-cloudflare --dns-cloudflare-credentials /opt/engram/certs/cloudflare-credentials.ini --deploy-hook 'docker exec engram-nginx nginx -s reload'
   ```

### Credentials Updated
- Cloudflare Global API Key: `~/.config/cloud-api-keys.env` (placeholder → real key)
- Cloudflare Zone ID added: `bf1855afd80dd24704e74f5d1ad963e9`
- Vault updated: `~/Projects/Infra/Infra Docs/00_Vault/cloud-api-keys.env`

### Cloudflare API Script Limitation
- `cloudflare_api.py` uses `Authorization: Bearer` (for API Tokens)
- Global API Key requires `X-Auth-Email` + `X-Auth-Key` headers
- Script works via direct `curl` with proper headers, not via the skill script
- Wildcard cert was obtained using `certbot` with correct `dns_cloudflare_email` + `dns_cloudflare_api_key` credentials file format

## Devnode Deployment

- Platform frontend rebuilt at `2026-03-22T00:01:19` (from previous session)
- All 8 services healthy (4-day uptime)
- Container: `engram-platform-frontend` healthy
- Wildcard cert now served by nginx on devnode

## Commands Run

```bash
# Test Cloudflare key
curl -s -X GET "https://api.cloudflare.com/client/v4/zones/bf1855afd80dd24704e74f5d1ad963e9" \
  -H "X-Auth-Email: acampkinpersonnal@gmail.com" \
  -H "X-Auth-Key: 5058bc51f6eef7609970994b78146bb35f2a9"

# Create certbot credentials file on devnode
ssh root@100.78.187.5 "cat > /opt/engram/certs/cloudflare-credentials.ini << 'EOF'
dns_cloudflare_email = acampkinpersonnal@gmail.com
dns_cloudflare_api_key = 5058bc51f6eef7609970994b78146bb35f2a9
EOF"

# Obtain wildcard cert
ssh root@100.78.187.5 "certbot certonly --dns-cloudflare \
  --dns-cloudflare-credentials /opt/engram/certs/cloudflare-credentials.ini \
  -d '*.velocitydigi.com' --non-interactive"

# Copy to correct mount point
ssh root@100.78.187.5 "cp /etc/letsencrypt/live/velocitydigi.com/fullchain.pem \
  /opt/engram/Engram-Platform/certs/velocitydigi.crt"
ssh root@100.78.187.5 "cp /etc/letsencrypt/live/velocitydigi.com/privkey.pem \
  /opt/engram/Engram-Platform/certs/velocitydigi.key"

# Update nginx.conf SSL paths (via sed) then restart
ssh root@100.78.187.5 "sed -i 's|nginx-selfsigned|velocitydigi|g' \
  /opt/engram/Engram-Platform/nginx/nginx.conf"
ssh root@100.78.187.5 "docker restart engram-nginx"

# Verify cert
openssl x509 -in <(ssh root@100.78.187.5 'cat /etc/letsencrypt/live/velocitydigi.com/fullchain.pem') \
  -noout -dates -subject

# Verify HTTPS
curl -sI -L --max-time 10 -k "https://memory.velocitydigi.com"
```

## Files Modified

- `~/.config/cloud-api-keys.env` — updated CLOUDFLARE_API_KEY (placeholder → real), added CLOUDFLARE_ZONE_ID
- `~/Projects/Infra/Infra Docs/00_Vault/cloud-api-keys.env` — updated CLOUDFLARE_API_KEY
- `/opt/engram/Engram-Platform/nginx/nginx.conf` — ssl_certificate paths updated
- `/opt/engram/Engram-Platform/certs/` — velocitydigi.crt, velocitydigi.key added
- `/opt/engram/certs/cloudflare-credentials.ini` — created on devnode
- `/etc/cron.d/certbot-renewal` — created on devnode
