# CHANGELOG — 2026-03-22 — Engram-AiCrawler AGENTS.md Generation

**Date:** 2026-03-22
**Status:** COMPLETED
**Task:** Generate comprehensive AGENTS.md files for all key directories in Engram-AiCrawler subproject

## Summary

Generated 15 AGENTS.md files for the Engram-AiCrawler FastAPI backend and React frontend, documenting purpose, structure, key files, subdirectories, working patterns, testing requirements, and dependencies for each directory level.

## Files Created

### Backend Documentation (11 files)

1. **`Engram-AiCrawler/01_devroot/AGENTS.md`** (169 lines)
   - Root dev directory: FastAPI backend + React frontend + supervisord process management

2. **`Engram-AiCrawler/01_devroot/app/AGENTS.md`** (162 lines)
   - FastAPI application root: route handlers, models, services, OSINT, orchestrators

3. **`Engram-AiCrawler/01_devroot/app/api/AGENTS.md`** (145 lines)
   - API endpoints: crawl, chat, data, extraction, investigations, knowledge graph, RAG, storage, stats

4. **`Engram-AiCrawler/01_devroot/app/api/osint/AGENTS.md`** (89 lines)
   - OSINT-specific endpoints: alias discovery, threat intel, fraud, image intel, deep crawl

5. **`Engram-AiCrawler/01_devroot/app/models/AGENTS.md`** (92 lines)
   - Pydantic request/response schemas for API validation

6. **`Engram-AiCrawler/01_devroot/app/orchestrators/AGENTS.md`** (85 lines)
   - High-level workflow coordinators (crawl planning, multi-stage OSINT)

7. **`Engram-AiCrawler/01_devroot/app/osint/AGENTS.md`** (147 lines)
   - OSINT services: alias discovery (8 platforms), threat intel, email/WHOIS/DNS, image search, face recognition

8. **`Engram-AiCrawler/01_devroot/app/osint/darkweb/AGENTS.md`** (70 lines)
   - Darkweb OSINT: breach scanning, crypto tracing, marketplace monitoring, Tor crawler

9. **`Engram-AiCrawler/01_devroot/app/pipelines/AGENTS.md`** (55 lines)
   - Data processing pipelines: entity enrichment, model review (LM Studio filtering)

10. **`Engram-AiCrawler/01_devroot/app/services/AGENTS.md`** (162 lines)
    - Business logic services: caching, LM Studio bridge, dedup, scheduler, Redis, RAG, data lifecycle

11. **`Engram-AiCrawler/01_devroot/app/storage/AGENTS.md`** (62 lines)
    - Vector database client (ChromaDB) and storage abstraction

### Frontend Documentation (4 files)

12. **`Engram-AiCrawler/01_devroot/frontend/AGENTS.md`** (152 lines)
    - React 18 frontend root: Vite, vitest, Playwright, Tailwind CSS, Zustand

13. **`Engram-AiCrawler/01_devroot/frontend/src/AGENTS.md`** (132 lines)
    - Source root: components, pages, hooks, stores, layouts, context, utilities

14. **`Engram-AiCrawler/01_devroot/frontend/src/components/AGENTS.md`** (118 lines)
    - Reusable UI components: base, charts, crawl, OSINT, graph, extraction, results, RAG, etc.

### Test Documentation (1 file)

15. **`Engram-AiCrawler/01_devroot/tests/AGENTS.md`** (58 lines)
    - Python unit and integration tests: pytest, fixtures, mocking patterns, 80% coverage threshold

## Key Content Includes

### Structure Documentation
- **Parent references**: All files include `<!-- Parent: ../AGENTS.md -->` for hierarchy
- **Purpose statements**: One-paragraph summary of each directory's role
- **Key files tables**: Lists all critical files with descriptions
- **Subdirectories**: Nested directory structure with purpose mappings

### Developer Guidance
- **Working patterns**: Step-by-step instructions for adding code in each directory
- **Testing requirements**: Coverage thresholds, test file organization, async/mock patterns
- **Common patterns**: Code snippets for typical patterns (FastAPI routers, React hooks, Pydantic models, etc.)

### Dependencies
- **Internal**: Cross-references to related directories
- **External**: Third-party libraries (FastAPI, React, Crawl4AI, LM Studio, Redis, ChromaDB, etc.)

## Architecture Insights Documented

1. **FastAPI Stack**
   - 5-stage OSINT pipeline: alias discovery → crawl → model review → store → knowledge graph
   - Async-first design with semaphore-based concurrency control
   - Redis caching with stampede prevention via mutex pattern
   - LM Studio local inference bridge for AI analysis

2. **React Frontend**
   - Component-driven architecture with feature-based subdirectories
   - Zustand for state management (crawlStore, notificationStore, osintStore, etc.)
   - Custom hooks for data fetching, API communication, WebSocket subscriptions
   - Vitest for unit testing, Playwright for E2E testing

3. **OSINT Services**
   - 8-platform alias discovery (social media, people search, etc.)
   - Darkweb monitoring (Tor, breach databases, marketplace crawlers)
   - Threat intelligence and fraud detection
   - Image-based OSINT (reverse search, face recognition)

## Testing & Verification

All 15 files:
- ✓ Generated from actual directory exploration
- ✓ Verified file paths and structures
- ✓ Consistent template format across all files
- ✓ Include practical code examples and patterns
- ✓ Reference actual framework/library versions used
- ✓ Total: 898 lines of documentation

## Next Steps for AI Agents

When working in Engram-AiCrawler directories, agents should:

1. **Consult local AGENTS.md** before making changes to understand architecture and patterns
2. **Follow "Working In This Directory" sections** for standard procedures
3. **Run tests listed in "Testing Requirements"** before committing
4. **Check "Common Patterns" sections** for code style guidance
5. **Verify "Dependencies" sections** when adding new imports

## Notes

- Root `Engram-AiCrawler/AGENTS.md` existed before this task; other files were created fresh
- All documentation is current as of 2026-03-22
- Generated by Writer agent (Haiku 4.5) using careful exploration of actual codebase structure
